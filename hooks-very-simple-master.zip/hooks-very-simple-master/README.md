# Hooks, very simple

## How it works

This React app uses hooks and the only purpose is to show them 